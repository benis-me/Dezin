# @capability-foundry/agent-ui

Accessible React primitives for rendering agent progress and decisions without
coupling the UI to an agent runtime or a product screen.

React 19 is required because closed disclosure content uses React's boolean
`inert` support to keep hidden controls out of keyboard focus order.

```tsx
import { AgentLoadingState, AgentTaskRow } from "@capability-foundry/agent-ui";
import "@capability-foundry/agent-ui/styles.css";
```

## Public components

- `AgentLoadingState`, `AgentThinking`, and `AgentStreamingText`
- `AgentToolGroup` and `AgentToolRows`
- `AgentApproval` and `AgentRecommendation`
- `AgentTaskRow` and `AgentJobDisclosure`
- `AgentContext` and `AgentInsights`

Workflow data and actions are supplied by the host. Disclosure primitives
support controlled state where their public props expose it; short-lived local
presentation state remains internal. The package does not invent agent events,
task state, context, metrics, or actions.

## Copy contract

The primitives ship generic English fallbacks so they remain useful without an
i18n layer and preserve the existing Dezin DOM and visual output. Hosts can
replace workflow-facing copy without wrapping or forking a component:

- `AgentThinking`, `AgentApproval`, `AgentToolGroup`, `AgentToolRows`,
  `AgentRecommendation`, and `AgentInsights` accept typed `labels` props.
- `AgentTaskRow` and `AgentJobDisclosure` accept `statusLabel` for visible
  status text and `ariaLabel` for their disclosure trigger.
- `AgentLoadingState`, `AgentStreamingText`, and `AgentContext` expose their
  existing `label`, `ariaLabel`, and `title` props.

Workflow-specific wording remains the host application's responsibility.

## Styling contract

Import `styles.css` once. The stylesheet consumes host design tokens including
`--background`, `--foreground`, `--card`, `--border`, `--primary`,
`--muted-foreground`, `--destructive`, and the standard shadow tokens. It does
not install a theme.

The current CSS keeps the historical `.dezin-agent-*` selectors and
`data-dezin-agent-*` attributes so existing Dezin screens migrate without a
visual change. New integrations should target the generic `Agent*` exports and
`data-agent-primitive` attributes. The prefixed surface is compatibility API,
not a product dependency. The generic English fallbacks are likewise part of
the Dezin-compatible rendering contract unless a host supplies replacement
copy.
