function findArrayEnd(source, start) {
  let depth = 0
  let inString = false
  let escaped = false

  for (let index = start; index < source.length; index++) {
    const character = source[index]
    if (inString) {
      if (escaped) escaped = false
      else if (character === '\\') escaped = true
      else if (character === '"') inString = false
      continue
    }

    if (character === '"') {
      inString = true
      continue
    }
    if (character === '[') depth++
    if (character !== ']') continue
    depth--
    if (depth === 0) return index
  }

  return -1
}

function isPackResult(value) {
  return (
    Array.isArray(value) &&
    value.length > 0 &&
    value.every(
      (entry) =>
        typeof entry === 'object' &&
        entry !== null &&
        typeof entry.filename === 'string' &&
        entry.filename.trim().length > 0,
    )
  )
}

/** Parse the last shape-valid JSON array from noisy `npm pack --json` output. */
export function parseNpmPackJson(stdout) {
  let match
  let matchStart = -1
  let matchEnd = -1

  for (let start = stdout.indexOf('['); start >= 0; start = stdout.indexOf('[', start + 1)) {
    const end = findArrayEnd(stdout, start)
    if (end < 0) continue

    try {
      const candidate = JSON.parse(stdout.slice(start, end + 1))
      if (
        isPackResult(candidate) &&
        (end > matchEnd || (end === matchEnd && start < matchStart))
      ) {
        match = candidate
        matchStart = start
        matchEnd = end
      }
    } catch {
      // Build/prepack logs can contain bracketed, non-JSON prefixes.
    }
  }

  if (!match) {
    throw new Error(
      'npm pack --json output did not contain a non-empty array of package records with filenames',
    )
  }
  return match
}
