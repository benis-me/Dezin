import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const packageRoot = dirname(dirname(fileURLToPath(import.meta.url)))
const dist = join(packageRoot, 'dist')
const files = []

function visit(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) visit(path)
    else if (entry.name.endsWith('.js')) files.push(path)
  }
}

visit(dist)

const imports = new Set()
for (const file of files) {
  const source = readFileSync(file, 'utf8')
  const patterns = [
    /\bfrom\s+['"]([^'"]+)['"]/g,
    /\bimport\s+['"]([^'"]+)['"]/g,
    /\bimport\s*\(\s*(?:\/\*[\s\S]*?\*\/\s*)?['"]([^'"]+)['"]\s*\)/g,
  ]

  for (const pattern of patterns) {
    for (const match of source.matchAll(pattern)) {
      const specifier = match[1]
      if (specifier) imports.add(`${file}\0${specifier}`)
    }
  }
}

for (const item of imports) {
  const [file, specifier] = item.split('\0')
  if (!file || !specifier || specifier.startsWith('node:')) continue

  if (specifier.startsWith('.')) {
    const target = resolve(dirname(file), specifier)
    if (!existsSync(target)) {
      throw new Error(`Unresolvable emitted import ${specifier} in ${file}`)
    }
    continue
  }

  const targetUrl = import.meta.resolve(specifier, pathToFileURL(file).href)
  if (targetUrl.startsWith('file:') && !existsSync(fileURLToPath(targetUrl))) {
    throw new Error(`Unresolvable emitted import ${specifier} in ${file}`)
  }
}

console.log(`[dist] ${files.length} modules and ${imports.size} imports resolve`)
