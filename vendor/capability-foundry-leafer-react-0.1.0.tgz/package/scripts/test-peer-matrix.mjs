import { cpSync, mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { parseNpmPackJson } from './pack-json.mjs'

const packageRoot = dirname(dirname(fileURLToPath(import.meta.url)))
const scratch = mkdtempSync(join(tmpdir(), 'leafer-react-compat-'))
const matrices = [
  {
    name: 'leafer-2.0-react-19.2',
    leafer: '2.0.8',
    react: '19.2.0',
  },
  {
    name: 'leafer-2.1-react-19.2',
    leafer: '2.1.10',
    react: '19.2.0',
  },
]

function run(command, args, cwd) {
  const result = spawnSync(command, args, {
    cwd,
    encoding: 'utf8',
    stdio: 'inherit',
    timeout: 120_000,
  })
  if (result.error) throw result.error
  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(' ')} exited with ${result.status}`)
  }
}

function capture(command, args, cwd) {
  const result = spawnSync(command, args, {
    cwd,
    encoding: 'utf8',
    timeout: 120_000,
  })
  if (result.error) throw result.error
  if (result.status !== 0) {
    process.stderr.write(result.stderr)
    throw new Error(`${command} ${args.join(' ')} exited with ${result.status}`)
  }
  return result.stdout
}

try {
  run('npm', ['run', 'build'], packageRoot)
  const packResult = parseNpmPackJson(
    capture('npm', ['pack', '--json', '--pack-destination', scratch], packageRoot),
  )
  const tarball = join(scratch, packResult[0].filename)

  for (const matrix of matrices) {
    const fixture = join(scratch, matrix.name)
    mkdirSync(fixture, { recursive: true })
    cpSync(join(packageRoot, 'src'), join(fixture, 'src'), { recursive: true })

    writeFileSync(
      join(fixture, 'package.json'),
      `${JSON.stringify(
        {
          name: `@capability-foundry/compat-${matrix.name}`,
          private: true,
          type: 'module',
          dependencies: {
            '@capability-foundry/leafer-react': `file:${tarball}`,
            '@leafer-in/editor': matrix.leafer,
            '@leafer-in/flow': matrix.leafer,
            '@types/react': '^19.0.0',
            '@types/react-reconciler': '0.33.0',
            'leafer-editor': matrix.leafer,
            react: matrix.react,
            'react-reconciler': '0.33.0',
            typescript: '5.9.3',
          },
        },
        null,
        2,
      )}\n`,
    )
    writeFileSync(
      join(fixture, 'tsconfig.json'),
      `${JSON.stringify(
        {
          compilerOptions: {
            target: 'ES2022',
            module: 'ESNext',
            moduleResolution: 'Bundler',
            jsx: 'react-jsx',
            lib: ['ES2022', 'DOM'],
            strict: true,
            noUncheckedIndexedAccess: true,
            exactOptionalPropertyTypes: true,
            skipLibCheck: true,
            noEmit: true,
          },
          include: ['src/**/*.ts', 'src/**/*.tsx', 'consumer.tsx'],
        },
        null,
        2,
      )}\n`,
    )
    writeFileSync(
      join(fixture, 'consumer.tsx'),
      `import { createElement } from 'react'\n` +
        `import { Leafer, Rect, ImageLighter, ViewportLighter, defineLeaferElement, type LeaferProps } from '@capability-foundry/leafer-react'\n` +
        `const Card = defineLeaferElement<{ label: string }>('Frame', { transform: ({ label }) => ({ name: label }) })\n` +
        `const props: LeaferProps = { editor: true, width: 800, height: 600 }\n` +
        `export const tree = createElement(Leafer, props, createElement(Rect, { fill: '#fff' }), createElement(Card, { label: 'Ideas' }))\n` +
        `export const plugins = [new ImageLighter({}, { disabled: true }), new ViewportLighter({}, { disabled: true })]\n`,
    )

    console.log(`\n[compat] ${matrix.name}`)
    run(
      'npm',
      ['install', '--ignore-scripts', '--no-audit', '--no-fund', '--package-lock=false'],
      fixture,
    )
    run(join(fixture, 'node_modules', '.bin', 'tsc'), ['-p', 'tsconfig.json'], fixture)
  }

  console.log('\n[compat] all supported peer combinations compile')
} finally {
  rmSync(scratch, { recursive: true, force: true })
}
