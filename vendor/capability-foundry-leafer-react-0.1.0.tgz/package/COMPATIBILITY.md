# Compatibility and private API policy

## Supported peers

| Leafer packages | React | React reconciler | Proven by |
| --- | --- | --- | --- |
| `2.0.8` | `19.2.0` | `0.33.0` | Awen/Bento Leafer baseline plus `test:compat` source compile |
| `2.1.10` | `19.2.0` | `0.33.0` | Dezin baseline plus `test:compat` source compile |

`leafer-editor`, `@leafer-in/editor`, and `@leafer-in/flow` must use the same
version. Peer ranges intentionally stop before Leafer 2.2. Supporting a newer
minor requires extending the matrix and completing the browser upgrade gate
below; a successful TypeScript compile alone is insufficient.

React is supported from 19.2 up to, but not including, React 20. The renderer
implementation depends on the React reconciler 0.33 host contract, whose own
peer requirement excludes React 19.0 and 19.1.

## Private runtime dependencies

These seams cannot be made stable by TypeScript declarations, so they are
documented and guarded explicitly:

| Area | Private surface | Failure posture |
| --- | --- | --- |
| React renderer | `react-reconciler` host config and positional `createContainer` contract | pinned major/minor dependency; public mount/update/unmount test |
| `ViewportLighter` | `renderer.renderOnce`, branch `__renderBranch`, `zoomLayer.__`, renderer canvas/view fields | installs lazily when shapes are present; `destroy()` restores original functions |
| `ImageLighter` | `LeaferImage.prototype.getLoadUrl`, `setThumbView`, `getThumbSize`, image `lod` fields | dynamic guarded import, reference-counted patch, original methods restored on final destroy |
| `<Leafer>` teardown | global `Resource.tasker` and `Resource.map` image queue fields | untouched by default; aggressive reset requires `exclusiveGlobalResourceOwnership` on every overlapping Foundry root and exclusive ownership of all native roots in the process |

The double-underscore fields are implementation details even when they appear
consistently in multiple Leafer releases. Do not expose them from Foundry's
public types or use them in consumer adapters.

## Dependency upgrade gate

Before widening any peer range:

1. Add the exact candidate version to `scripts/test-peer-matrix.mjs` and run
   `pnpm test:compat`.
2. Run `pnpm test`, `pnpm typecheck`, and `pnpm build`.
3. Install the packed tarball in a blank browser host—not a workspace source
   alias—and verify mount, prop/event updates, unmount, and editor selection.
4. With enough nodes to cross thresholds, pan and zoom while checking visible
   culling, edge pop-in, renderer stop/start, and hook restoration after
   `destroy()`.
5. Exercise image initial load, loaded-image stability, optional LOD switching,
   load failure, navigation teardown, and repeated plugin construction.

Record the tested browser, Leafer versions, and result next to the matrix change.
