export type LeaferEditorRuntime = {
  LeaferImage?: { prototype?: unknown }
}

/** Isolates the optional browser runtime import used by ImageLighter patches. */
export function loadLeaferEditorRuntime(): Promise<LeaferEditorRuntime> {
  return import(/* @vite-ignore */ 'leafer-editor')
}
