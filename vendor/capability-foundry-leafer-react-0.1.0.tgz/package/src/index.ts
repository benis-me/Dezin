export {
  Box,
  Ellipse,
  Flow,
  Frame,
  Group,
  Img,
  LImage,
  LText,
  Leafer,
  Line,
  Path,
  Pen,
  Polygon,
  Rect,
  Star,
  Txt,
  defineLeaferElement,
  type LeaferProps,
} from './components/index.js'

export { LeaferContext } from './context/leafer-context.js'
export { useLeafer } from './hooks/use-leafer.js'
export { useEditor, type EditorControls } from './hooks/use-editor.js'
export { render, unmount } from './core/renderer.js'
export { registerComponent, registerElement } from './core/element-registry.js'
export {
  ImageLighter,
  isImageLighterLoading,
  type ImageLighterLevel,
  type ImageLighterOptions,
} from './plugins/image-lighter.js'
export {
  ViewportLighter,
  type ViewportLighterOptions,
} from './plugins/viewport-lighter.js'
// Registers the built-in Leafer classes once when the public entry point loads.
import './core/leafer-elements.js'
