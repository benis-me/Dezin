import { defineLeaferElement } from './factory.js'

export const Frame = defineLeaferElement('Frame')
export const Group = defineLeaferElement('Group')
export const Box = defineLeaferElement('Box')
export const Flow = defineLeaferElement('Flow')

export const Rect = defineLeaferElement('Rect')
export const Ellipse = defineLeaferElement('Ellipse')
export const Star = defineLeaferElement('Star')
export const Polygon = defineLeaferElement('Polygon')
export const Line = defineLeaferElement('Line')
export const Path = defineLeaferElement('Path')
export const Pen = defineLeaferElement('Pen', {
  transform: (props: Record<string, unknown>) => {
    const { path, ...rest } = props
    return path ? { tag: 'Path', props: { ...rest, path } } : rest
  },
})

export const Img = defineLeaferElement('Image')
export const Txt = defineLeaferElement('Text', {
  transform: (props: Record<string, unknown>) => ({
    ...props,
    text: props.text ?? props.children,
  }),
})

/** @deprecated Prefer {@link Img}. */
export const LImage = Img
/** @deprecated Prefer {@link Txt}. */
export const LText = Txt

export { Leafer, type LeaferProps } from './leafer.js'
export { defineLeaferElement } from './factory.js'
