import {
  createElement,
  type ReactElement,
  type ReactNode,
} from 'react'

type LeaferElementProps = Record<string, unknown>
type LeaferElementRedirect = {
  tag: string
  props: LeaferElementProps
}

type NamedLeaferComponent<P> = ((
  props: P & { children?: ReactNode }
) => ReactElement<LeaferElementProps>) & { displayName: string }

interface DefineOptions<P> {
  transform?: (
    props: P & { children?: ReactNode },
  ) => LeaferElementProps | LeaferElementRedirect
}

function isElementRedirect(
  value: LeaferElementProps | LeaferElementRedirect,
): value is LeaferElementRedirect {
  return (
    typeof value.tag === 'string' &&
    typeof value.props === 'object' &&
    value.props !== null
  )
}

/** Create a named React component that the Leafer reconciler can consume. */
export function defineLeaferElement<P = Record<string, unknown>>(
  tag: string,
  options?: DefineOptions<P>,
): NamedLeaferComponent<P> {
  function Component(props: P & { children?: ReactNode }) {
    const { children, ...rest } = props
    const transformed = options?.transform
      ? options.transform(props)
      : rest

    if (isElementRedirect(transformed)) {
      const { children: transformedChildren, ...nativeProps } = transformed.props
      return createElement(
        transformed.tag,
        nativeProps,
        children ?? (transformedChildren as ReactNode),
      )
    }

    const { children: transformedChildren, ...nativeProps } = transformed
    return createElement(
      tag,
      nativeProps,
      children ?? (transformedChildren as ReactNode),
    )
  }

  Component.displayName = tag.charAt(0).toUpperCase() + tag.slice(1)
  return Component
}
