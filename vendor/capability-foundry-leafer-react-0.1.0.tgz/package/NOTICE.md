# Source provenance

`@capability-foundry/leafer-react` is a distillation of three MIT-licensed
in-repository packages. The original copyright notices are retained in
`LICENSE`.

| Source | Original package | Relevant history |
| --- | --- | --- |
| Dezin | `packages/leafer-react` | `a048f3a5c74c158b39e43bde8e149e38b89ab6e8`, `27112e8dd47d376147a31b0ba4cee71c44ed2e6e`, `58b0475b050abc13ed86e3656ef489f32b7c1c5b`, `2ff2b4cc6ec9e93899130a3e858723083df8ec4f` |
| Awen | `packages/leafer-react` | `97d852833fbbfb821d0b5886811e30cf282b8222`, `51fc80abd1868e67d06349ba267faa591decf087`, `ae7e31dc897784912cfa4baac81bfc7a5f513a98` |
| Bento | `packages/leafer-react` | `bdd0c177eb01b27f0f65f788775224207b1262cf` |

The 2026-08-21 comparison excluded `dist`, `node_modules`, and coverage output.
The public reconciler, components, hooks, and plugin behavior were equivalent
across the three forks. Source-only differences were limited to project-named
global patch symbols, TypeScript spelling, and the Leafer peer version used by
each host. No fork was selected merely because it was newer.

Foundry changes are intentionally visible and test-backed:

- project-named patch state became
  `capability-foundry.leafer-react.image-lighter.patch`;
- emitted ESM uses explicit `.js` relative imports;
- strict optional-property typing was made explicit;
- component transforms now receive `children`, fixing the inherited
  `<Txt>label</Txt>` behavior;
- resize handling uses a safe pixel-ratio fallback when `window` is absent;
- public behavior tests and a Leafer/React source-compile matrix were added.

Keep this notice with copied or redistributed source so future changes can be
traced back to the original repositories and commits.
