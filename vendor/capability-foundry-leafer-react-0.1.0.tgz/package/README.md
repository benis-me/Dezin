# `@capability-foundry/leafer-react`

A React 19 reconciler bridge for Leafer 2.0–2.1 canvas trees. It packages the
shared behavior proven in Dezin, Awen, and Bento: declarative Leafer elements,
App lifecycle ownership, editor hooks, viewport culling, and image LOD.

## Install

```sh
pnpm add @capability-foundry/leafer-react react leafer-editor \
  @leafer-in/editor @leafer-in/flow
```

All three Leafer packages must resolve to the same version. See
[COMPATIBILITY.md](./COMPATIBILITY.md) before upgrading Leafer or React.

## Canvas

```tsx
import { Leafer, Rect, Txt } from '@capability-foundry/leafer-react'

export function Canvas() {
  return (
    <Leafer editor>
      <Rect x={20} y={20} width={240} height={120} fill="#f3efe7" />
      <Txt x={40} y={48}>Reusable canvas</Txt>
    </Leafer>
  )
}
```

`defineLeaferElement` and `registerElement` expose the extension seam for
custom Leafer classes. `render` and `unmount` are available when a host already
owns the Leafer `App`.

By default, unmounting `<Leafer>` never resets Leafer's process-global image
queue because roots created through another wrapper or directly with `new App()`
cannot be counted safely. A host that owns **every** Leafer root in the current
JavaScript process may opt into the legacy aggressive cleanup:

```tsx
<Leafer exclusiveGlobalResourceOwnership>{/* ... */}</Leafer>
```

Every overlapping Foundry root must opt in; otherwise that root cohort leaves
the global queue untouched. Do not enable this prop in an embedded canvas or a
process that also creates native Leafer roots.

## Performance helpers

```ts
import {
  ImageLighter,
  ViewportLighter,
} from '@capability-foundry/leafer-react'

const viewport = new ViewportLighter(app.tree)
const images = new ImageLighter(app.tree, {
  switchLoadedImages: false,
})

// During host teardown:
images.destroy()
viewport.destroy()
```

Both helpers are opt-out/fail-soft wrappers around Leafer runtime behavior.
Always call `destroy()` so listeners and temporary patches are released.
Multiple `ViewportLighter` handles for the same target share the first handle's
controller and options; the target patch remains live until the final handle is
destroyed, regardless of destroy order.

## Verification

```sh
pnpm test
pnpm typecheck
pnpm build
pnpm test:compat
```

Tests exercise behavior through the package's public entry point. External
Leafer classes are boundary fakes in unit tests; the compatibility matrix then
compiles the real source against each declared peer baseline. A real browser
canvas playtest remains required for dependency upgrades because the
performance helpers touch private renderer internals.

The package is browser-oriented. Rendering a `<Leafer>` requires DOM, canvas,
and `ResizeObserver`; importing it in an SSR server bundle may also evaluate
Leafer's browser runtime.
