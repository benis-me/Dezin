# design-foundation

The semantic visual foundation distilled from Dezin's current product proof:
warm-neutral surfaces, graphite/coral interaction roles, OKLCH light and dark
themes, restrained overlay shadows, expressive type scale, and four motion
curves.

Use the CSS preset:

```css
@import "@capability-foundry/design-foundation/theme.css";
```

Or consume `studioLightTheme`, `studioDarkTheme`, and
`themeToCssVariables` from TypeScript. Layout, brand copy, screen composition,
and component-specific styling remain product-owned.
