# Source notice

This package distills MIT-licensed behavior from Dezin `apps/web/src/styles/globals.css` at
`f72f8060dc984e005f3050f9ca7e33c13a111279`. Capability Foundry owns the
product-neutral contract, tests, and subsequent modifications; Dezin retains
its product composition and compatibility facade.

